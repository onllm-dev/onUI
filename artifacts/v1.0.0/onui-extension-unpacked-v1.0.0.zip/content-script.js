var ht = Object.defineProperty;
var gt = (t, e, n) => e in t ? ht(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n;
var ce = (t, e, n) => gt(t, typeof e != "symbol" ? e + "" : e, n);
var ie, $, Ye, W, ke, Xe, qe, Ge, me, fe, he, K = {}, Ke = [], _t = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i, se = Array.isArray;
function P(t, e) {
  for (var n in e) t[n] = e[n];
  return t;
}
function ve(t) {
  t && t.parentNode && t.parentNode.removeChild(t);
}
function bt(t, e, n) {
  var o, i, r, a = {};
  for (r in e) r == "key" ? o = e[r] : r == "ref" ? i = e[r] : a[r] = e[r];
  if (arguments.length > 2 && (a.children = arguments.length > 3 ? ie.call(arguments, 2) : n), typeof t == "function" && t.defaultProps != null) for (r in t.defaultProps) a[r] === void 0 && (a[r] = t.defaultProps[r]);
  return ee(t, a, o, i, null);
}
function ee(t, e, n, o, i) {
  var r = { type: t, props: e, key: n, ref: o, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: i ?? ++Ye, __i: -1, __u: 0 };
  return i == null && $.vnode != null && $.vnode(r), r;
}
function U(t) {
  return t.children;
}
function te(t, e) {
  this.props = t, this.context = e;
}
function V(t, e) {
  if (e == null) return t.__ ? V(t.__, t.__i + 1) : null;
  for (var n; e < t.__k.length; e++) if ((n = t.__k[e]) != null && n.__e != null) return n.__e;
  return typeof t.type == "function" ? V(t) : null;
}
function Je(t) {
  var e, n;
  if ((t = t.__) != null && t.__c != null) {
    for (t.__e = t.__c.base = null, e = 0; e < t.__k.length; e++) if ((n = t.__k[e]) != null && n.__e != null) {
      t.__e = t.__c.base = n.__e;
      break;
    }
    return Je(t);
  }
}
function $e(t) {
  (!t.__d && (t.__d = !0) && W.push(t) && !oe.__r++ || ke != $.debounceRendering) && ((ke = $.debounceRendering) || Xe)(oe);
}
function oe() {
  for (var t, e, n, o, i, r, a, u = 1; W.length; ) W.length > u && W.sort(qe), t = W.shift(), u = W.length, t.__d && (n = void 0, o = void 0, i = (o = (e = t).__v).__e, r = [], a = [], e.__P && ((n = P({}, o)).__v = o.__v + 1, $.vnode && $.vnode(n), xe(e.__P, n, o, e.__n, e.__P.namespaceURI, 32 & o.__u ? [i] : null, r, i ?? V(o), !!(32 & o.__u), a), n.__v = o.__v, n.__.__k[n.__i] = n, et(r, n, a), o.__e = o.__ = null, n.__e != i && Je(n)));
  oe.__r = 0;
}
function Qe(t, e, n, o, i, r, a, u, d, c, h) {
  var s, f, p, b, v, y, g, _ = o && o.__k || Ke, w = e.length;
  for (d = mt(n, e, _, d, w), s = 0; s < w; s++) (p = n.__k[s]) != null && (f = p.__i == -1 ? K : _[p.__i] || K, p.__i = s, y = xe(t, p, f, i, r, a, u, d, c, h), b = p.__e, p.ref && f.ref != p.ref && (f.ref && ye(f.ref, null, p), h.push(p.ref, p.__c || b, p)), v == null && b != null && (v = b), (g = !!(4 & p.__u)) || f.__k === p.__k ? d = Ze(p, d, t, g) : typeof p.type == "function" && y !== void 0 ? d = y : b && (d = b.nextSibling), p.__u &= -7);
  return n.__e = v, d;
}
function mt(t, e, n, o, i) {
  var r, a, u, d, c, h = n.length, s = h, f = 0;
  for (t.__k = new Array(i), r = 0; r < i; r++) (a = e[r]) != null && typeof a != "boolean" && typeof a != "function" ? (typeof a == "string" || typeof a == "number" || typeof a == "bigint" || a.constructor == String ? a = t.__k[r] = ee(null, a, null, null, null) : se(a) ? a = t.__k[r] = ee(U, { children: a }, null, null, null) : a.constructor === void 0 && a.__b > 0 ? a = t.__k[r] = ee(a.type, a.props, a.key, a.ref ? a.ref : null, a.__v) : t.__k[r] = a, d = r + f, a.__ = t, a.__b = t.__b + 1, u = null, (c = a.__i = vt(a, n, d, s)) != -1 && (s--, (u = n[c]) && (u.__u |= 2)), u == null || u.__v == null ? (c == -1 && (i > h ? f-- : i < h && f++), typeof a.type != "function" && (a.__u |= 4)) : c != d && (c == d - 1 ? f-- : c == d + 1 ? f++ : (c > d ? f-- : f++, a.__u |= 4))) : t.__k[r] = null;
  if (s) for (r = 0; r < h; r++) (u = n[r]) != null && !(2 & u.__u) && (u.__e == o && (o = V(u)), nt(u, u));
  return o;
}
function Ze(t, e, n, o) {
  var i, r;
  if (typeof t.type == "function") {
    for (i = t.__k, r = 0; i && r < i.length; r++) i[r] && (i[r].__ = t, e = Ze(i[r], e, n, o));
    return e;
  }
  t.__e != e && (o && (e && t.type && !e.parentNode && (e = V(t)), n.insertBefore(t.__e, e || null)), e = t.__e);
  do
    e = e && e.nextSibling;
  while (e != null && e.nodeType == 8);
  return e;
}
function vt(t, e, n, o) {
  var i, r, a, u = t.key, d = t.type, c = e[n], h = c != null && (2 & c.__u) == 0;
  if (c === null && u == null || h && u == c.key && d == c.type) return n;
  if (o > (h ? 1 : 0)) {
    for (i = n - 1, r = n + 1; i >= 0 || r < e.length; ) if ((c = e[a = i >= 0 ? i-- : r++]) != null && !(2 & c.__u) && u == c.key && d == c.type) return a;
  }
  return -1;
}
function Ce(t, e, n) {
  e[0] == "-" ? t.setProperty(e, n ?? "") : t[e] = n == null ? "" : typeof n != "number" || _t.test(e) ? n : n + "px";
}
function Z(t, e, n, o, i) {
  var r, a;
  e: if (e == "style") if (typeof n == "string") t.style.cssText = n;
  else {
    if (typeof o == "string" && (t.style.cssText = o = ""), o) for (e in o) n && e in n || Ce(t.style, e, "");
    if (n) for (e in n) o && n[e] == o[e] || Ce(t.style, e, n[e]);
  }
  else if (e[0] == "o" && e[1] == "n") r = e != (e = e.replace(Ge, "$1")), a = e.toLowerCase(), e = a in t || e == "onFocusOut" || e == "onFocusIn" ? a.slice(2) : e.slice(2), t.l || (t.l = {}), t.l[e + r] = n, n ? o ? n.u = o.u : (n.u = me, t.addEventListener(e, r ? he : fe, r)) : t.removeEventListener(e, r ? he : fe, r);
  else {
    if (i == "http://www.w3.org/2000/svg") e = e.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
    else if (e != "width" && e != "height" && e != "href" && e != "list" && e != "form" && e != "tabIndex" && e != "download" && e != "rowSpan" && e != "colSpan" && e != "role" && e != "popover" && e in t) try {
      t[e] = n ?? "";
      break e;
    } catch {
    }
    typeof n == "function" || (n == null || n === !1 && e[4] != "-" ? t.removeAttribute(e) : t.setAttribute(e, e == "popover" && n == 1 ? "" : n));
  }
}
function Ee(t) {
  return function(e) {
    if (this.l) {
      var n = this.l[e.type + t];
      if (e.t == null) e.t = me++;
      else if (e.t < n.u) return;
      return n($.event ? $.event(e) : e);
    }
  };
}
function xe(t, e, n, o, i, r, a, u, d, c) {
  var h, s, f, p, b, v, y, g, _, w, m, x, E, z, D, M, B, O = e.type;
  if (e.constructor !== void 0) return null;
  128 & n.__u && (d = !!(32 & n.__u), r = [u = e.__e = n.__e]), (h = $.__b) && h(e);
  e: if (typeof O == "function") try {
    if (g = e.props, _ = "prototype" in O && O.prototype.render, w = (h = O.contextType) && o[h.__c], m = h ? w ? w.props.value : h.__ : o, n.__c ? y = (s = e.__c = n.__c).__ = s.__E : (_ ? e.__c = s = new O(g, m) : (e.__c = s = new te(g, m), s.constructor = O, s.render = yt), w && w.sub(s), s.state || (s.state = {}), s.__n = o, f = s.__d = !0, s.__h = [], s._sb = []), _ && s.__s == null && (s.__s = s.state), _ && O.getDerivedStateFromProps != null && (s.__s == s.state && (s.__s = P({}, s.__s)), P(s.__s, O.getDerivedStateFromProps(g, s.__s))), p = s.props, b = s.state, s.__v = e, f) _ && O.getDerivedStateFromProps == null && s.componentWillMount != null && s.componentWillMount(), _ && s.componentDidMount != null && s.__h.push(s.componentDidMount);
    else {
      if (_ && O.getDerivedStateFromProps == null && g !== p && s.componentWillReceiveProps != null && s.componentWillReceiveProps(g, m), e.__v == n.__v || !s.__e && s.shouldComponentUpdate != null && s.shouldComponentUpdate(g, s.__s, m) === !1) {
        for (e.__v != n.__v && (s.props = g, s.state = s.__s, s.__d = !1), e.__e = n.__e, e.__k = n.__k, e.__k.some(function(F) {
          F && (F.__ = e);
        }), x = 0; x < s._sb.length; x++) s.__h.push(s._sb[x]);
        s._sb = [], s.__h.length && a.push(s);
        break e;
      }
      s.componentWillUpdate != null && s.componentWillUpdate(g, s.__s, m), _ && s.componentDidUpdate != null && s.__h.push(function() {
        s.componentDidUpdate(p, b, v);
      });
    }
    if (s.context = m, s.props = g, s.__P = t, s.__e = !1, E = $.__r, z = 0, _) {
      for (s.state = s.__s, s.__d = !1, E && E(e), h = s.render(s.props, s.state, s.context), D = 0; D < s._sb.length; D++) s.__h.push(s._sb[D]);
      s._sb = [];
    } else do
      s.__d = !1, E && E(e), h = s.render(s.props, s.state, s.context), s.state = s.__s;
    while (s.__d && ++z < 25);
    s.state = s.__s, s.getChildContext != null && (o = P(P({}, o), s.getChildContext())), _ && !f && s.getSnapshotBeforeUpdate != null && (v = s.getSnapshotBeforeUpdate(p, b)), M = h, h != null && h.type === U && h.key == null && (M = tt(h.props.children)), u = Qe(t, se(M) ? M : [M], e, n, o, i, r, a, u, d, c), s.base = e.__e, e.__u &= -161, s.__h.length && a.push(s), y && (s.__E = s.__ = null);
  } catch (F) {
    if (e.__v = null, d || r != null) if (F.then) {
      for (e.__u |= d ? 160 : 128; u && u.nodeType == 8 && u.nextSibling; ) u = u.nextSibling;
      r[r.indexOf(u)] = null, e.__e = u;
    } else {
      for (B = r.length; B--; ) ve(r[B]);
      ge(e);
    }
    else e.__e = n.__e, e.__k = n.__k, F.then || ge(e);
    $.__e(F, e, n);
  }
  else r == null && e.__v == n.__v ? (e.__k = n.__k, e.__e = n.__e) : u = e.__e = xt(n.__e, e, n, o, i, r, a, d, c);
  return (h = $.diffed) && h(e), 128 & e.__u ? void 0 : u;
}
function ge(t) {
  t && t.__c && (t.__c.__e = !0), t && t.__k && t.__k.forEach(ge);
}
function et(t, e, n) {
  for (var o = 0; o < n.length; o++) ye(n[o], n[++o], n[++o]);
  $.__c && $.__c(e, t), t.some(function(i) {
    try {
      t = i.__h, i.__h = [], t.some(function(r) {
        r.call(i);
      });
    } catch (r) {
      $.__e(r, i.__v);
    }
  });
}
function tt(t) {
  return typeof t != "object" || t == null || t.__b && t.__b > 0 ? t : se(t) ? t.map(tt) : P({}, t);
}
function xt(t, e, n, o, i, r, a, u, d) {
  var c, h, s, f, p, b, v, y = n.props || K, g = e.props, _ = e.type;
  if (_ == "svg" ? i = "http://www.w3.org/2000/svg" : _ == "math" ? i = "http://www.w3.org/1998/Math/MathML" : i || (i = "http://www.w3.org/1999/xhtml"), r != null) {
    for (c = 0; c < r.length; c++) if ((p = r[c]) && "setAttribute" in p == !!_ && (_ ? p.localName == _ : p.nodeType == 3)) {
      t = p, r[c] = null;
      break;
    }
  }
  if (t == null) {
    if (_ == null) return document.createTextNode(g);
    t = document.createElementNS(i, _, g.is && g), u && ($.__m && $.__m(e, r), u = !1), r = null;
  }
  if (_ == null) y === g || u && t.data == g || (t.data = g);
  else {
    if (r = r && ie.call(t.childNodes), !u && r != null) for (y = {}, c = 0; c < t.attributes.length; c++) y[(p = t.attributes[c]).name] = p.value;
    for (c in y) if (p = y[c], c != "children") {
      if (c == "dangerouslySetInnerHTML") s = p;
      else if (!(c in g)) {
        if (c == "value" && "defaultValue" in g || c == "checked" && "defaultChecked" in g) continue;
        Z(t, c, null, p, i);
      }
    }
    for (c in g) p = g[c], c == "children" ? f = p : c == "dangerouslySetInnerHTML" ? h = p : c == "value" ? b = p : c == "checked" ? v = p : u && typeof p != "function" || y[c] === p || Z(t, c, p, y[c], i);
    if (h) u || s && (h.__html == s.__html || h.__html == t.innerHTML) || (t.innerHTML = h.__html), e.__k = [];
    else if (s && (t.innerHTML = ""), Qe(e.type == "template" ? t.content : t, se(f) ? f : [f], e, n, o, _ == "foreignObject" ? "http://www.w3.org/1999/xhtml" : i, r, a, r ? r[0] : n.__k && V(n, 0), u, d), r != null) for (c = r.length; c--; ) ve(r[c]);
    u || (c = "value", _ == "progress" && b == null ? t.removeAttribute("value") : b != null && (b !== t[c] || _ == "progress" && !b || _ == "option" && b != y[c]) && Z(t, c, b, y[c], i), c = "checked", v != null && v != t[c] && Z(t, c, v, y[c], i));
  }
  return t;
}
function ye(t, e, n) {
  try {
    if (typeof t == "function") {
      var o = typeof t.__u == "function";
      o && t.__u(), o && e == null || (t.__u = t(e));
    } else t.current = e;
  } catch (i) {
    $.__e(i, n);
  }
}
function nt(t, e, n) {
  var o, i;
  if ($.unmount && $.unmount(t), (o = t.ref) && (o.current && o.current != t.__e || ye(o, null, e)), (o = t.__c) != null) {
    if (o.componentWillUnmount) try {
      o.componentWillUnmount();
    } catch (r) {
      $.__e(r, e);
    }
    o.base = o.__P = null;
  }
  if (o = t.__k) for (i = 0; i < o.length; i++) o[i] && nt(o[i], e, n || typeof t.type != "function");
  n || ve(t.__e), t.__c = t.__ = t.__e = void 0;
}
function yt(t, e, n) {
  return this.constructor(t, n);
}
function wt(t, e, n) {
  var o, i, r, a;
  e == document && (e = document.documentElement), $.__ && $.__(t, e), i = (o = !1) ? null : e.__k, r = [], a = [], xe(e, t = e.__k = bt(U, null, [t]), i || K, K, e.namespaceURI, i ? null : e.firstChild ? ie.call(e.childNodes) : null, r, i ? i.__e : e.firstChild, o, a), et(r, t, a);
}
ie = Ke.slice, $ = { __e: function(t, e, n, o) {
  for (var i, r, a; e = e.__; ) if ((i = e.__c) && !i.__) try {
    if ((r = i.constructor) && r.getDerivedStateFromError != null && (i.setState(r.getDerivedStateFromError(t)), a = i.__d), i.componentDidCatch != null && (i.componentDidCatch(t, o || {}), a = i.__d), a) return i.__E = i;
  } catch (u) {
    t = u;
  }
  throw t;
} }, Ye = 0, te.prototype.setState = function(t, e) {
  var n;
  n = this.__s != null && this.__s != this.state ? this.__s : this.__s = P({}, this.state), typeof t == "function" && (t = t(P({}, n), this.props)), t && P(n, t), t != null && this.__v && (e && this._sb.push(e), $e(this));
}, te.prototype.forceUpdate = function(t) {
  this.__v && (this.__e = !0, t && this.__h.push(t), $e(this));
}, te.prototype.render = U, W = [], Xe = typeof Promise == "function" ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, qe = function(t, e) {
  return t.__v.__b - e.__v.__b;
}, oe.__r = 0, Ge = /(PointerCapture)$|Capture$/i, me = 0, fe = Ee(!1), he = Ee(!0);
var kt = 0;
function l(t, e, n, o, i, r) {
  e || (e = {});
  var a, u, d = e;
  if ("ref" in d) for (u in d = {}, e) u == "ref" ? a = e[u] : d[u] = e[u];
  var c = { type: t, props: d, key: n, ref: a, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: --kt, __i: -1, __u: 0, __source: i, __self: r };
  if (typeof t == "function" && (a = t.defaultProps)) for (u in a) d[u] === void 0 && (d[u] = a[u]);
  return $.vnode && $.vnode(c), c;
}
const Se = "onui-shadow-host";
class $t {
  constructor() {
    ce(this, "host", null);
    ce(this, "shadow", null);
  }
  /**
   * Initialize the shadow host if not already present
   */
  init() {
    if (this.shadow)
      return this.shadow;
    let e = document.getElementById(Se);
    return e && (this.host = e, this.shadow = e.shadowRoot, this.shadow) ? this.shadow : (this.host = document.createElement("div"), this.host.id = Se, this.host.style.cssText = `
      position: absolute;
      top: 0;
      left: 0;
      width: 0;
      height: 0;
      overflow: visible;
      z-index: 2147483647;
      pointer-events: none;
    `, this.shadow = this.host.attachShadow({ mode: "closed" }), document.body.appendChild(this.host), this.shadow);
  }
  /**
   * Get the shadow root
   */
  getShadowRoot() {
    return this.shadow;
  }
  /**
   * Destroy the shadow host
   */
  destroy() {
    this.host && this.host.parentNode && this.host.parentNode.removeChild(this.host), this.host = null, this.shadow = null;
  }
}
const Ct = new $t(), Et = ':root{--onui-primary: #6366f1;--onui-primary-hover: #4f46e5;--onui-primary-active: #4338ca;--onui-bg: #ffffff;--onui-bg-secondary: #f9fafb;--onui-bg-tertiary: #f3f4f6;--onui-text: #111827;--onui-text-secondary: #6b7280;--onui-text-tertiary: #9ca3af;--onui-border: #e5e7eb;--onui-border-hover: #d1d5db;--onui-success: #10b981;--onui-warning: #f59e0b;--onui-error: #ef4444;--onui-shadow-sm: 0 1px 2px 0 rgb(0 0 0 / .05);--onui-shadow: 0 1px 3px 0 rgb(0 0 0 / .1), 0 1px 2px -1px rgb(0 0 0 / .1);--onui-shadow-md: 0 4px 6px -1px rgb(0 0 0 / .1), 0 2px 4px -2px rgb(0 0 0 / .1);--onui-shadow-lg: 0 10px 15px -3px rgb(0 0 0 / .1), 0 4px 6px -4px rgb(0 0 0 / .1);--onui-spacing-xs: 4px;--onui-spacing-sm: 8px;--onui-spacing-md: 12px;--onui-spacing-lg: 16px;--onui-spacing-xl: 24px;--onui-radius-sm: 4px;--onui-radius: 6px;--onui-radius-md: 8px;--onui-radius-lg: 12px;--onui-radius-full: 9999px;--onui-font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;--onui-font-size-xs: 11px;--onui-font-size-sm: 12px;--onui-font-size: 14px;--onui-font-size-lg: 16px;--onui-transition: .15s ease;--onui-transition-fast: .1s ease}', St = ".onui-toolbar{position:fixed;display:flex;align-items:center;gap:var(--onui-spacing-xs);padding:var(--onui-spacing-xs);background:var(--onui-bg);border:1px solid var(--onui-border);border-radius:var(--onui-radius-lg);box-shadow:var(--onui-shadow-lg);font-family:var(--onui-font-family);font-size:var(--onui-font-size-sm);z-index:2147483647;pointer-events:auto;-webkit-user-select:none;user-select:none}.onui-toolbar-draggable{display:flex;align-items:center;justify-content:center;width:20px;height:32px;cursor:grab;color:var(--onui-text-tertiary);flex-shrink:0}.onui-toolbar-draggable:active{cursor:grabbing}.onui-toolbar-draggable svg{width:12px;height:12px}.onui-toolbar-divider{width:1px;height:24px;background:var(--onui-border);flex-shrink:0}.onui-toolbar-button{display:flex;align-items:center;justify-content:center;width:32px;height:32px;padding:0;border:none;border-radius:var(--onui-radius);background:transparent;color:var(--onui-text-secondary);cursor:pointer;transition:all var(--onui-transition-fast)}.onui-toolbar-button:hover{background:var(--onui-bg-tertiary);color:var(--onui-text)}.onui-toolbar-button:active{background:var(--onui-border)}.onui-toolbar-button.active{background:var(--onui-primary);color:#fff}.onui-toolbar-button.active:hover{background:var(--onui-primary-hover)}.onui-toolbar-button svg{width:18px;height:18px}.onui-toolbar-button-label{display:flex;align-items:center;gap:var(--onui-spacing-xs);padding:0 var(--onui-spacing-sm);height:32px;font-size:var(--onui-font-size-sm);font-weight:500;color:var(--onui-text);white-space:nowrap}.onui-toolbar-badge{display:flex;align-items:center;justify-content:center;min-width:20px;height:20px;padding:0 6px;margin-left:var(--onui-spacing-xs);font-size:11px;font-weight:600;color:#fff;background:var(--onui-primary);border-radius:10px}@keyframes onui-spin{to{transform:rotate(360deg)}}.onui-loading-spinner{border:2px solid var(--onui-border);border-top-color:var(--onui-primary);border-radius:50%;animation:onui-spin .6s linear infinite}.onui-error-toast{position:fixed;bottom:var(--onui-spacing-lg);left:50%;transform:translate(-50%);display:flex;align-items:center;gap:var(--onui-spacing-sm);padding:var(--onui-spacing-sm) var(--onui-spacing-md);background:var(--onui-error);color:#fff;border-radius:var(--onui-radius);box-shadow:var(--onui-shadow-lg);font-family:var(--onui-font-family);font-size:var(--onui-font-size-sm);z-index:2147483647;animation:onui-toast-in .2s ease}@keyframes onui-toast-in{0%{opacity:0;transform:translate(-50%) translateY(10px)}to{opacity:1;transform:translate(-50%) translateY(0)}}.onui-error-toast-content{display:flex;align-items:center;gap:var(--onui-spacing-sm)}.onui-error-toast-icon{width:16px;height:16px;flex-shrink:0}.onui-error-toast-message{max-width:300px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.onui-error-toast-dismiss{display:flex;align-items:center;justify-content:center;width:20px;height:20px;padding:0;margin-left:var(--onui-spacing-xs);background:#fff3;border:none;border-radius:var(--onui-radius-sm);color:#fff;cursor:pointer;transition:background var(--onui-transition-fast)}.onui-error-toast-dismiss:hover{background:#ffffff4d}.onui-error-toast-dismiss svg{width:12px;height:12px}.onui-toolbar-button:disabled{opacity:.5;cursor:not-allowed}.onui-toolbar-button:disabled:hover{background:transparent;color:var(--onui-text-secondary)}.onui-toolbar-button.success{background:var(--onui-success);color:#fff}.onui-toolbar-button.success:hover{background:#059669}", At = ".onui-popup-overlay{position:fixed;top:0;left:0;width:100%;height:100%;background:#0003;z-index:2147483645;pointer-events:auto}.onui-popup{position:absolute;min-width:280px;max-width:400px;background:var(--onui-bg);border:1px solid var(--onui-border);border-radius:var(--onui-radius-lg);box-shadow:var(--onui-shadow-lg);font-family:var(--onui-font-family);font-size:var(--onui-font-size);z-index:2147483647;pointer-events:auto;overflow:hidden}.onui-popup-header{display:flex;align-items:center;justify-content:space-between;padding:var(--onui-spacing-sm) var(--onui-spacing-md);border-bottom:1px solid var(--onui-border);background:var(--onui-bg-secondary)}.onui-popup-title{font-size:var(--onui-font-size-sm);font-weight:600;color:var(--onui-text);margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.onui-popup-close{display:flex;align-items:center;justify-content:center;width:24px;height:24px;padding:0;border:none;border-radius:var(--onui-radius-sm);background:transparent;color:var(--onui-text-secondary);cursor:pointer;transition:all var(--onui-transition-fast)}.onui-popup-close:hover{background:var(--onui-bg-tertiary);color:var(--onui-text)}.onui-popup-body{padding:var(--onui-spacing-md)}.onui-popup-textarea{width:100%;min-height:80px;padding:var(--onui-spacing-sm);border:1px solid var(--onui-border);border-radius:var(--onui-radius);font-family:var(--onui-font-family);font-size:var(--onui-font-size);color:var(--onui-text);background:var(--onui-bg);resize:vertical;box-sizing:border-box}.onui-popup-textarea:focus{outline:none;border-color:var(--onui-primary);box-shadow:0 0 0 2px #6366f133}.onui-popup-textarea::placeholder{color:var(--onui-text-tertiary)}.onui-popup-footer{display:flex;align-items:center;justify-content:space-between;gap:var(--onui-spacing-sm);padding:var(--onui-spacing-sm) var(--onui-spacing-md);border-top:1px solid var(--onui-border);background:var(--onui-bg-secondary)}.onui-popup-actions{display:flex;gap:var(--onui-spacing-sm)}.onui-btn{display:inline-flex;align-items:center;justify-content:center;gap:var(--onui-spacing-xs);height:32px;padding:0 var(--onui-spacing-md);border:1px solid var(--onui-border);border-radius:var(--onui-radius);font-family:var(--onui-font-family);font-size:var(--onui-font-size-sm);font-weight:500;color:var(--onui-text);background:var(--onui-bg);cursor:pointer;transition:all var(--onui-transition-fast);white-space:nowrap}.onui-btn:hover{background:var(--onui-bg-tertiary);border-color:var(--onui-border-hover)}.onui-btn-primary{background:var(--onui-primary);border-color:var(--onui-primary);color:#fff}.onui-btn-primary:hover{background:var(--onui-primary-hover);border-color:var(--onui-primary-hover)}.onui-btn-danger{color:var(--onui-error);border-color:var(--onui-error)}.onui-btn-danger:hover{background:var(--onui-error);color:#fff}.onui-btn-icon{width:32px;padding:0}.onui-btn svg{width:16px;height:16px}", Tt = ".onui-toolbar{--onui-bg: rgba(23, 23, 23, .95);--onui-bg-glass: rgba(38, 38, 38, .8);--onui-bg-hover: rgba(83, 87, 255, .16);--onui-bg-active: rgba(83, 87, 255, .24);--onui-border: rgba(255, 255, 255, .1);--onui-border-hover: rgba(130, 141, 255, .5);--onui-text: #fafafa;--onui-text-secondary: #b8bad1;--onui-text-muted: #71717a;--onui-primary: #5b63ff;--onui-primary-hover: #737dff;--onui-success: #22c55e;--onui-warning: #f59e0b;--onui-error: #ef4444;--onui-shadow: 0 18px 40px -18px rgba(0, 0, 0, .65);--onui-blur: 16px}.onui-toolbar{position:fixed;bottom:16px;right:16px;display:flex;flex-direction:column-reverse;align-items:flex-end;gap:6px;z-index:2147483647;pointer-events:auto;font-family:var(--onui-font-family)}.onui-toggle{display:flex;align-items:center;justify-content:center;width:40px;height:40px;padding:0;border:1px solid var(--onui-border);border-radius:12px;background:var(--onui-bg);backdrop-filter:blur(var(--onui-blur));-webkit-backdrop-filter:blur(var(--onui-blur));color:var(--onui-text);cursor:pointer;box-shadow:var(--onui-shadow);transition:all .15s ease}.onui-toggle:hover{background:linear-gradient(140deg,#5b63ff57,#49c6ff2e);border-color:var(--onui-border-hover);transform:scale(1.05)}.onui-toggle:active{transform:scale(.98)}.onui-toggle.active{background:linear-gradient(140deg,var(--onui-primary),#4ec7ff);border-color:var(--onui-primary)}.onui-toggle.active:hover{background:linear-gradient(140deg,var(--onui-primary-hover),#6ad2ff)}.onui-toggle:focus-visible{outline:2px solid rgba(106,210,255,.7);outline-offset:2px}.onui-toggle svg{width:17px;height:17px}.onui-panel{display:flex;flex-direction:column;gap:2px;width:112px;padding:5px;background:linear-gradient(165deg,#171717f5,#1c1f2df5);backdrop-filter:blur(var(--onui-blur));-webkit-backdrop-filter:blur(var(--onui-blur));border:1px solid var(--onui-border);border-radius:12px;box-shadow:var(--onui-shadow);animation:onui-panel-in .15s ease;box-sizing:border-box}@keyframes onui-panel-in{0%{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}.onui-panel-header{display:flex;align-items:center;justify-content:space-between;padding:4px 8px 7px;border-bottom:1px solid var(--onui-border);margin-bottom:4px}.onui-panel-title{font-size:11px;font-weight:600;color:var(--onui-text);letter-spacing:-.01em}.onui-panel-title-accent{color:#67d3ff;text-shadow:0 0 12px rgba(103,211,255,.35)}.onui-panel-badge{display:flex;align-items:center;justify-content:center;min-width:18px;height:18px;padding:0 5px;font-size:10px;font-weight:600;color:#fff;background:var(--onui-primary);border-radius:10px}.onui-btn{display:flex;align-items:center;gap:7px;width:100%;padding:7px 8px;border:1px solid transparent;border-radius:7px;background:transparent;color:var(--onui-text-secondary);font-family:inherit;font-size:11px;font-weight:500;text-align:left;cursor:pointer;transition:all .14s ease}.onui-btn:hover{background:linear-gradient(140deg,#5b63ff38,#4ec7ff1f);border-color:#828dff73;color:var(--onui-text)}.onui-btn:active{background:var(--onui-bg-active)}.onui-btn.active{background:linear-gradient(140deg,var(--onui-primary),#4ec7ff);color:#fff}.onui-btn.active:hover{background:linear-gradient(140deg,var(--onui-primary-hover),#6ad2ff)}.onui-btn:focus-visible{outline:2px solid rgba(106,210,255,.7);outline-offset:2px}.onui-btn svg{width:14px;height:14px;flex-shrink:0}.onui-btn-label{white-space:nowrap}.onui-divider{height:1px;background:var(--onui-border);margin:2px 0}.onui-settings{display:flex;flex-direction:column;gap:6px;padding:5px;margin-top:2px;border-top:1px solid var(--onui-border)}.onui-setting-row{display:flex;flex-direction:column;align-items:flex-start;gap:6px}.onui-setting-label{font-size:11px;color:var(--onui-text-secondary)}.onui-select{width:100%;min-width:0;padding:6px 8px;background:var(--onui-bg-glass);border:1px solid var(--onui-border);border-radius:6px;color:var(--onui-text);font-family:inherit;font-size:11px;cursor:pointer;outline:none}.onui-select:hover{border-color:var(--onui-border-hover)}.onui-select:focus{border-color:var(--onui-primary)}.onui-dialog-backdrop{position:fixed;top:0;right:0;bottom:0;left:0;background:#0006;-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px);z-index:2147483646;animation:onui-fade-in .15s ease;pointer-events:auto}@keyframes onui-fade-in{0%{opacity:0}to{opacity:1}}.onui-dialog{position:fixed;z-index:2147483647;display:flex;flex-direction:column;width:360px;max-height:500px;padding:16px;background:var(--onui-bg);backdrop-filter:blur(var(--onui-blur));-webkit-backdrop-filter:blur(var(--onui-blur));border:1px solid var(--onui-border);border-radius:16px;box-shadow:var(--onui-shadow);font-family:var(--onui-font-family);animation:onui-dialog-in .2s ease;overflow:hidden;pointer-events:auto}@keyframes onui-dialog-in{0%{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.onui-dialog-header{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:16px}.onui-dialog-title{font-size:15px;font-weight:600;color:var(--onui-text)}.onui-dialog-subtitle{font-size:12px;color:var(--onui-text-muted);margin-top:4px}.onui-dialog-close{display:flex;align-items:center;justify-content:center;width:28px;height:28px;padding:0;border:none;border-radius:8px;background:transparent;color:var(--onui-text-secondary);cursor:pointer;transition:all .1s ease}.onui-dialog-close:hover{background:var(--onui-bg-hover);color:var(--onui-text)}.onui-dialog-close svg{width:16px;height:16px}.onui-textarea{width:100%;min-height:80px;padding:12px;background:var(--onui-bg-glass);border:1px solid var(--onui-border);border-radius:10px;color:var(--onui-text);font-family:inherit;font-size:14px;line-height:1.5;resize:vertical;outline:none;transition:border-color .15s ease}.onui-textarea::placeholder{color:var(--onui-text-muted)}.onui-textarea:hover{border-color:var(--onui-border-hover)}.onui-textarea:focus{border-color:var(--onui-primary)}.onui-selector{display:flex;flex-wrap:wrap;gap:6px;margin-top:12px}.onui-selector-label{width:100%;font-size:12px;font-weight:500;color:var(--onui-text-secondary);margin-bottom:4px}.onui-chip{display:flex;align-items:center;gap:6px;padding:6px 12px;border:1px solid var(--onui-border);border-radius:20px;background:transparent;color:var(--onui-text-secondary);font-family:inherit;font-size:12px;font-weight:500;cursor:pointer;outline:none;transition:all .14s ease}.onui-chip:hover{background:#ffffff14;border-color:var(--onui-border-hover);color:var(--onui-text);transform:translateY(-1px)}.onui-chip:active{transform:translateY(0)}.onui-chip:focus-visible{border-color:var(--onui-primary);box-shadow:0 0 0 2px #6366f173,0 0 0 4px #6366f12e}.onui-chip.is-selected{background:var(--onui-primary);border-color:var(--onui-primary);color:#fff;box-shadow:0 0 0 1px #818cf88c,0 8px 20px -10px #6366f1a6}.onui-chip.is-selected:hover{background:var(--onui-primary-hover);border-color:var(--onui-primary-hover);color:#fff}.onui-chip.is-selected:focus-visible{box-shadow:0 0 0 2px #818cf899,0 0 0 4px #818cf840,0 8px 20px -10px #6366f1a6}.onui-chip svg{width:14px;height:14px}.onui-styles{margin-top:12px;padding:10px;background:var(--onui-bg-glass);border:1px solid var(--onui-border);border-radius:8px;max-height:120px;overflow-y:auto}.onui-styles-title{font-size:11px;font-weight:600;color:var(--onui-text-muted);text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px}.onui-style-row{display:flex;justify-content:space-between;gap:12px;font-size:12px;line-height:1.6}.onui-style-key{color:var(--onui-text-muted);font-family:SF Mono,Monaco,Inconsolata,monospace}.onui-style-value{color:var(--onui-text);font-family:SF Mono,Monaco,Inconsolata,monospace;text-align:right;word-break:break-all}.onui-dialog-footer{display:flex;justify-content:flex-end;gap:8px;margin-top:16px;padding-top:16px;border-top:1px solid var(--onui-border)}.onui-btn-secondary{padding:10px 16px;border:1px solid var(--onui-border);border-radius:8px;background:transparent;color:var(--onui-text-secondary);font-family:inherit;font-size:13px;font-weight:500;cursor:pointer;transition:all .1s ease}.onui-btn-secondary:hover{background:var(--onui-bg-hover);color:var(--onui-text)}.onui-btn-primary{padding:10px 20px;border:none;border-radius:8px;background:var(--onui-primary);color:#fff;font-family:inherit;font-size:13px;font-weight:600;cursor:pointer;transition:all .1s ease}.onui-btn-primary:hover{background:var(--onui-primary-hover)}.onui-btn-primary:disabled{opacity:.5;cursor:not-allowed}.onui-component-path{display:flex;align-items:center;gap:6px;padding:8px 10px;margin-top:12px;background:#6366f11a;border:1px solid rgba(99,102,241,.2);border-radius:8px;font-size:12px;color:var(--onui-primary-hover);font-family:SF Mono,Monaco,Inconsolata,monospace;overflow-x:auto;white-space:nowrap}.onui-component-path svg{width:14px;height:14px;flex-shrink:0}.onui-dialog ::-webkit-scrollbar{width:6px}.onui-dialog ::-webkit-scrollbar-track{background:transparent}.onui-dialog ::-webkit-scrollbar-thumb{background:var(--onui-border);border-radius:3px}.onui-dialog ::-webkit-scrollbar-thumb:hover{background:var(--onui-border-hover)}.onui-refresh-banner{position:fixed;top:20px;right:20px;padding:12px 16px;background:var(--onui-warning, #f59e0b);color:#000;border-radius:8px;font-family:var(--onui-font-family);font-size:13px;font-weight:500;z-index:2147483647;pointer-events:auto;display:flex;align-items:center;gap:12px;box-shadow:0 25px 50px -12px #00000080;animation:onui-panel-in .15s ease}.onui-refresh-banner button{padding:6px 12px;background:#000;color:#fff;border:none;border-radius:4px;cursor:pointer;font-weight:500;font-size:12px;font-family:inherit}.onui-refresh-banner button:hover{background:#333}";
function It(t) {
  const e = document.createElement("style");
  e.textContent = `
    ${Et}
    ${St}
    ${At}
    ${Tt}
  `, t.appendChild(e);
}
var Y, A, ue, Ae, J = 0, ot = [], I = $, Te = I.__b, Ie = I.__r, Me = I.diffed, Ne = I.__c, Re = I.unmount, ze = I.__;
function ae(t, e) {
  I.__h && I.__h(A, t, J || e), J = 0;
  var n = A.__H || (A.__H = { __: [], __h: [] });
  return t >= n.__.length && n.__.push({}), n.__[t];
}
function T(t) {
  return J = 1, Mt(rt, t);
}
function Mt(t, e, n) {
  var o = ae(Y++, 2);
  if (o.t = t, !o.__c && (o.__ = [rt(void 0, e), function(u) {
    var d = o.__N ? o.__N[0] : o.__[0], c = o.t(d, u);
    d !== c && (o.__N = [c, o.__[1]], o.__c.setState({}));
  }], o.__c = A, !A.__f)) {
    var i = function(u, d, c) {
      if (!o.__c.__H) return !0;
      var h = o.__c.__H.__.filter(function(f) {
        return !!f.__c;
      });
      if (h.every(function(f) {
        return !f.__N;
      })) return !r || r.call(this, u, d, c);
      var s = o.__c.props !== u;
      return h.forEach(function(f) {
        if (f.__N) {
          var p = f.__[0];
          f.__ = f.__N, f.__N = void 0, p !== f.__[0] && (s = !0);
        }
      }), r && r.call(this, u, d, c) || s;
    };
    A.__f = !0;
    var r = A.shouldComponentUpdate, a = A.componentWillUpdate;
    A.componentWillUpdate = function(u, d, c) {
      if (this.__e) {
        var h = r;
        r = void 0, i(u, d, c), r = h;
      }
      a && a.call(this, u, d, c);
    }, A.shouldComponentUpdate = i;
  }
  return o.__N || o.__;
}
function R(t, e) {
  var n = ae(Y++, 3);
  !I.__s && we(n.__H, e) && (n.__ = t, n.u = e, A.__H.__h.push(n));
}
function Nt(t, e) {
  var n = ae(Y++, 4);
  !I.__s && we(n.__H, e) && (n.__ = t, n.u = e, A.__h.push(n));
}
function N(t) {
  return J = 5, le(function() {
    return { current: t };
  }, []);
}
function le(t, e) {
  var n = ae(Y++, 7);
  return we(n.__H, e) && (n.__ = t(), n.__H = e, n.__h = t), n.__;
}
function S(t, e) {
  return J = 8, le(function() {
    return t;
  }, e);
}
function Rt() {
  for (var t; t = ot.shift(); ) if (t.__P && t.__H) try {
    t.__H.__h.forEach(ne), t.__H.__h.forEach(_e), t.__H.__h = [];
  } catch (e) {
    t.__H.__h = [], I.__e(e, t.__v);
  }
}
I.__b = function(t) {
  A = null, Te && Te(t);
}, I.__ = function(t, e) {
  t && e.__k && e.__k.__m && (t.__m = e.__k.__m), ze && ze(t, e);
}, I.__r = function(t) {
  Ie && Ie(t), Y = 0;
  var e = (A = t.__c).__H;
  e && (ue === A ? (e.__h = [], A.__h = [], e.__.forEach(function(n) {
    n.__N && (n.__ = n.__N), n.u = n.__N = void 0;
  })) : (e.__h.forEach(ne), e.__h.forEach(_e), e.__h = [], Y = 0)), ue = A;
}, I.diffed = function(t) {
  Me && Me(t);
  var e = t.__c;
  e && e.__H && (e.__H.__h.length && (ot.push(e) !== 1 && Ae === I.requestAnimationFrame || ((Ae = I.requestAnimationFrame) || zt)(Rt)), e.__H.__.forEach(function(n) {
    n.u && (n.__H = n.u), n.u = void 0;
  })), ue = A = null;
}, I.__c = function(t, e) {
  e.some(function(n) {
    try {
      n.__h.forEach(ne), n.__h = n.__h.filter(function(o) {
        return !o.__ || _e(o);
      });
    } catch (o) {
      e.some(function(i) {
        i.__h && (i.__h = []);
      }), e = [], I.__e(o, n.__v);
    }
  }), Ne && Ne(t, e);
}, I.unmount = function(t) {
  Re && Re(t);
  var e, n = t.__c;
  n && n.__H && (n.__H.__.forEach(function(o) {
    try {
      ne(o);
    } catch (i) {
      e = i;
    }
  }), n.__H = void 0, e && I.__e(e, n.__v));
};
var He = typeof requestAnimationFrame == "function";
function zt(t) {
  var e, n = function() {
    clearTimeout(o), He && cancelAnimationFrame(e), setTimeout(t);
  }, o = setTimeout(n, 35);
  He && (e = requestAnimationFrame(n));
}
function ne(t) {
  var e = A, n = t.__c;
  typeof n == "function" && (t.__c = void 0, n()), A = e;
}
function _e(t) {
  var e = A;
  t.__c = t.__(), A = e;
}
function we(t, e) {
  return !t || t.length !== e.length || e.some(function(n, o) {
    return n !== t[o];
  });
}
function rt(t, e) {
  return typeof e == "function" ? e(t) : e;
}
function Le(t) {
  const e = t.getBoundingClientRect();
  return {
    top: e.top,
    left: e.left,
    width: e.width,
    height: e.height
  };
}
function Ht(t, e) {
  return t.top === e.top && t.left === e.left && t.width === e.width && t.height === e.height;
}
function de({ element: t, color: e = "#6366f1", selected: n = !1 }) {
  const [o, i] = T(() => Le(t));
  Nt(() => {
    let u = null, d = !1;
    const c = () => {
      if (d)
        return;
      const h = Le(t);
      i((s) => Ht(s, h) ? s : h), u = window.requestAnimationFrame(c);
    };
    return c(), () => {
      d = !0, u !== null && window.cancelAnimationFrame(u);
    };
  }, [t]);
  const r = n ? "#f97316" : e, a = le(() => ({
    position: "fixed",
    top: `${o.top}px`,
    left: `${o.left}px`,
    width: `${o.width}px`,
    height: `${o.height}px`,
    border: `2px solid ${r}`,
    backgroundColor: `${r}20`,
    pointerEvents: "none",
    boxSizing: "border-box",
    zIndex: 2147483646
  }), [o, r]);
  return /* @__PURE__ */ l("div", { style: a });
}
function it() {
  const [t, e] = T(0), n = N(null);
  return R(() => {
    const o = () => {
      n.current === null && (n.current = window.requestAnimationFrame(() => {
        n.current = null, e((i) => i + 1);
      }));
    };
    return window.addEventListener("scroll", o, { capture: !0, passive: !0 }), window.addEventListener("resize", o), () => {
      window.removeEventListener("scroll", o, { capture: !0 }), window.removeEventListener("resize", o), n.current !== null && (window.cancelAnimationFrame(n.current), n.current = null);
    };
  }, []), t;
}
function Lt({
  annotation: t,
  index: e,
  onClick: n
}) {
  const o = it(), { boundingBox: i } = t, r = le(() => {
    if (!i)
      return null;
    const u = 20, d = 8, c = 4, h = (v, y, g) => g < y ? y : Math.min(Math.max(v, y), g), s = i.top - d, f = i.left + i.width - d;
    let p = s, b = f;
    if (i.isFixed) {
      const v = window.innerHeight - u - c, y = window.innerWidth - u - c;
      p = h(s, c, v), b = h(f, c, y);
    } else {
      const v = window.scrollY + c, y = window.scrollX + c, g = window.scrollY + window.innerHeight - u - c, _ = window.scrollX + window.innerWidth - u - c;
      p = h(s, v, g), b = h(f, y, _);
    }
    return {
      position: i.isFixed ? "fixed" : "absolute",
      top: `${p}px`,
      left: `${b}px`,
      width: `${u}px`,
      height: `${u}px`,
      borderRadius: "50%",
      background: "var(--onui-primary)",
      color: "white",
      fontSize: "11px",
      fontWeight: "600",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      cursor: "pointer",
      boxShadow: "var(--onui-shadow)",
      border: "2px solid white",
      zIndex: 2147483644,
      transition: "transform var(--onui-transition-fast)",
      fontFamily: "var(--onui-font-family)"
    };
  }, [i, o]);
  return r ? /* @__PURE__ */ l(
    "div",
    {
      class: "onui-marker",
      style: r,
      onClick: (u) => {
        u.preventDefault(), u.stopPropagation(), n(t);
      },
      title: t.comment,
      children: e + 1
    }
  ) : null;
}
function Ot({
  annotations: t,
  onMarkerClick: e
}) {
  return t.length === 0 ? null : /* @__PURE__ */ l(U, { children: t.map((n, o) => /* @__PURE__ */ l(
    Lt,
    {
      annotation: n,
      index: o,
      onClick: e
    },
    n.id
  )) });
}
function re(t, e) {
  return t.length <= e ? t : `${t.slice(0, e - 3)}...`;
}
function Dt(t, e) {
  const n = [`# ${e.title}`, `URL: ${e.url}`, ""];
  return t.forEach((o, i) => {
    let r = `${i + 1}. \`${o.selector}\` > ${o.comment}`;
    o.selectedText && (r += ` (selected: "${re(o.selectedText, 50)}")`), n.push(r);
  }), n.join(`
`);
}
function Pt(t, e) {
  const n = [
    `# ${e.title}`,
    `URL: ${e.url}`,
    `Generated: ${e.timestamp}`,
    `Total annotations: ${t.length}`,
    ""
  ];
  return t.forEach((o, i) => {
    if (n.push(`## ${i + 1}. ${o.elementPath}`), n.push(""), n.push("### Element Info"), n.push(`- **Selector:** \`${o.selector}\``), n.push(`- **Tag:** \`${o.tagName}\``), n.push(`- **Path:** \`${o.elementPath}\``), o.role && n.push(`- **Role:** ${o.role}`), o.attributes && Object.keys(o.attributes).length > 0) {
      n.push(""), n.push("### Attributes");
      for (const [r, a] of Object.entries(o.attributes))
        n.push(`- \`${r}\`: \`${re(a, 80)}\``);
    }
    if (o.textContent && (n.push(""), n.push("### Text Content"), n.push("```"), n.push(re(o.textContent, 200)), n.push("```")), o.boundingBox) {
      const r = o.boundingBox;
      n.push(""), n.push("### Position"), n.push(`- **Top:** ${Math.round(r.top)}px`), n.push(`- **Left:** ${Math.round(r.left)}px`), n.push(`- **Width:** ${Math.round(r.width)}px`), n.push(`- **Height:** ${Math.round(r.height)}px`), r.isFixed && n.push("- **Position:** fixed");
    }
    n.push(""), n.push("### Annotation"), n.push(`**Comment:** ${o.comment}`), o.selectedText && (n.push(""), n.push("**Selected Text:**"), n.push("```"), n.push(o.selectedText), n.push("```")), n.push(""), n.push("---"), n.push("");
  }), n.join(`
`);
}
function Ft(t, e) {
  const n = [
    "# Forensic Annotation Report",
    "",
    "## Page Context",
    `- **Title:** ${e.title}`,
    `- **URL:** ${e.url}`,
    `- **Generated:** ${e.timestamp}`,
    `- **Viewport:** ${e.viewportWidth ?? 0}x${e.viewportHeight ?? 0}`,
    `- **Scroll position:** ${e.scrollX ?? 0}, ${e.scrollY ?? 0}`,
    `- **Document size:** ${e.documentWidth ?? 0}x${e.documentHeight ?? 0}`,
    `- **Total annotations:** ${t.length}`,
    "",
    "---",
    ""
  ];
  return t.forEach((o, i) => {
    if (n.push(`## Annotation ${i + 1}: ${o.id}`), n.push(""), n.push("### Metadata"), n.push(`- **ID:** \`${o.id}\``), n.push(`- **Created:** ${o.createdAt}`), o.updatedAt !== o.createdAt && n.push(`- **Updated:** ${o.updatedAt}`), n.push(""), n.push("### Element Identification"), n.push(`- **CSS Selector:** \`${o.selector}\``), n.push(`- **Element Path:** \`${o.elementPath}\``), n.push(`- **Tag Name:** \`${o.tagName}\``), o.role && n.push(`- **ARIA Role:** ${o.role}`), n.push(""), o.attributes && Object.keys(o.attributes).length > 0 && (n.push("### Attributes"), n.push("```json"), n.push(JSON.stringify(o.attributes, null, 2)), n.push("```"), n.push("")), o.boundingBox) {
      const r = o.boundingBox;
      n.push("### Bounding Box"), n.push("```json"), n.push(
        JSON.stringify(
          {
            top: Math.round(r.top),
            left: Math.round(r.left),
            width: Math.round(r.width),
            height: Math.round(r.height),
            bottom: r.bottom ? Math.round(r.bottom) : Math.round(r.top + r.height),
            right: r.right ? Math.round(r.right) : Math.round(r.left + r.width),
            isFixed: r.isFixed
          },
          null,
          2
        )
      ), n.push("```"), n.push("");
    }
    o.textContent && (n.push("### Text Content"), n.push("```"), n.push(o.textContent), n.push("```"), n.push("")), n.push("### Annotation Content"), n.push(""), n.push("**Comment:**"), n.push(`> ${o.comment}`), n.push(""), o.selectedText && (n.push("**Selected Text:**"), n.push("```"), n.push(o.selectedText), n.push("```"), n.push("")), n.push("### Raw JSON"), n.push("<details>"), n.push("<summary>Click to expand</summary>"), n.push(""), n.push("```json"), n.push(JSON.stringify(o, null, 2)), n.push("```"), n.push("</details>"), n.push(""), n.push("---"), n.push("");
  }), n.join(`
`);
}
function Ut(t) {
  var n, o;
  const e = [];
  if ((n = t.attributes) != null && n.id)
    e.push(`#${t.attributes.id}`);
  else if ((o = t.attributes) != null && o.class) {
    const i = t.attributes.class.split(" ")[0];
    i && e.push(`.${i}`);
  }
  return t.role && e.push(`[${t.role}]`), e.length === 0 && e.push(`<${t.tagName}>`), e.join(" ");
}
function jt(t, e) {
  const n = [
    `# ${e.title}`,
    `URL: ${e.url}`,
    `Generated: ${e.timestamp}`,
    ""
  ];
  return t.forEach((o, i) => {
    n.push(`## ${i + 1}. ${Ut(o)}`), n.push(`- **Selector:** \`${o.selector}\``), n.push(`- **Tag:** \`${o.tagName}\``), o.role && n.push(`- **Role:** ${o.role}`), n.push(`- **Comment:** ${o.comment}`), o.selectedText && n.push(`- **Selected text:** "${re(o.selectedText, 100)}"`), n.push("");
  }), n.join(`
`);
}
function Bt(t, e = "standard", n) {
  if (t.length === 0)
    return `# No annotations

No elements have been annotated yet.`;
  switch (e) {
    case "compact":
      return Dt(t, n);
    case "detailed":
      return Pt(t, n);
    case "forensic":
      return Ft(t, n);
    case "standard":
    default:
      return jt(t, n);
  }
}
function Wt(t, e = "standard") {
  return Bt(t, e, Vt());
}
function Vt() {
  return {
    url: window.location.href,
    title: document.title,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    viewportWidth: window.innerWidth,
    viewportHeight: window.innerHeight,
    scrollX: window.scrollX,
    scrollY: window.scrollY,
    documentWidth: document.documentElement.scrollWidth,
    documentHeight: document.documentElement.scrollHeight
  };
}
async function Yt(t) {
  try {
    return await navigator.clipboard.writeText(t), !0;
  } catch {
    return Xt(t);
  }
}
function Xt(t) {
  const e = document.createElement("textarea");
  e.value = t, e.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 2em;
    height: 2em;
    padding: 0;
    border: none;
    outline: none;
    boxShadow: none;
    background: transparent;
  `, document.body.appendChild(e), e.focus(), e.select();
  try {
    const n = document.execCommand("copy");
    return document.body.removeChild(e), n;
  } catch {
    return document.body.removeChild(e), !1;
  }
}
const qt = () => /* @__PURE__ */ l("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", children: [
  /* @__PURE__ */ l("path", { d: "M12 2L2 7l10 5 10-5-10-5z" }),
  /* @__PURE__ */ l("path", { d: "M2 17l10 5 10-5" }),
  /* @__PURE__ */ l("path", { d: "M2 12l10 5 10-5" })
] }), Gt = () => /* @__PURE__ */ l("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", children: [
  /* @__PURE__ */ l("circle", { cx: "12", cy: "12", r: "10" }),
  /* @__PURE__ */ l("line", { x1: "22", y1: "12", x2: "18", y2: "12" }),
  /* @__PURE__ */ l("line", { x1: "6", y1: "12", x2: "2", y2: "12" }),
  /* @__PURE__ */ l("line", { x1: "12", y1: "6", x2: "12", y2: "2" }),
  /* @__PURE__ */ l("line", { x1: "12", y1: "22", x2: "12", y2: "18" })
] }), Kt = () => /* @__PURE__ */ l("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", children: [
  /* @__PURE__ */ l("rect", { x: "9", y: "9", width: "13", height: "13", rx: "2", ry: "2" }),
  /* @__PURE__ */ l("path", { d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" })
] }), Jt = () => /* @__PURE__ */ l("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", children: [
  /* @__PURE__ */ l("polyline", { points: "3,6 5,6 21,6" }),
  /* @__PURE__ */ l("path", { d: "M19,6v14a2,2,0,0,1-2,2H7a2,2,0,0,1-2-2V6m3,0V4a2,2,0,0,1,2-2h4a2,2,0,0,1,2,2v2" })
] }), Qt = () => /* @__PURE__ */ l("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", children: [
  /* @__PURE__ */ l("circle", { cx: "12", cy: "12", r: "3" }),
  /* @__PURE__ */ l("path", { d: "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" })
] }), Zt = () => /* @__PURE__ */ l("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", children: /* @__PURE__ */ l("polyline", { points: "20,6 9,17 4,12" }) });
function en({
  isAnnotateMode: t,
  onToggleAnnotateMode: e,
  annotations: n,
  outputLevel: o,
  onOutputLevelChange: i,
  onClearAnnotations: r
}) {
  const a = "[onUI][toolbar]", [u, d] = T(!1), [c, h] = T(!1), [s, f] = T(!1), p = u, b = S(() => {
    d((g) => !g), h(!1);
  }, []);
  R(() => {
    const g = (_) => {
      _.key === "Escape" && t && e();
    };
    return document.addEventListener("keydown", g), () => document.removeEventListener("keydown", g);
  }, [t, e]);
  const v = S(async () => {
    if (n.length === 0) {
      console.log(`${a} no annotations to copy`);
      return;
    }
    const g = Wt(n, o);
    await Yt(g) ? (f(!0), setTimeout(() => f(!1), 2e3), console.log(`${a} annotations copied to clipboard`)) : console.error(`${a} failed to copy annotations`);
  }, [n, o, a]), y = S(() => {
    n.length !== 0 && (r(), console.log(`${a} annotations cleared`));
  }, [n.length, r, a]);
  return /* @__PURE__ */ l("div", { class: "onui-toolbar", children: [
    p && /* @__PURE__ */ l("div", { class: "onui-panel", children: [
      /* @__PURE__ */ l("div", { class: "onui-panel-header", children: [
        /* @__PURE__ */ l("span", { class: "onui-panel-title", children: [
          "on",
          /* @__PURE__ */ l("span", { class: "onui-panel-title-accent", children: "UI" })
        ] }),
        n.length > 0 && /* @__PURE__ */ l("span", { class: "onui-panel-badge", children: n.length })
      ] }),
      /* @__PURE__ */ l(
        "button",
        {
          class: `onui-btn ${t ? "active" : ""}`,
          onClick: e,
          children: [
            /* @__PURE__ */ l(Gt, {}),
            /* @__PURE__ */ l("span", { class: "onui-btn-label", children: t ? "Annotating..." : "Annotate" })
          ]
        }
      ),
      /* @__PURE__ */ l(
        "button",
        {
          class: `onui-btn ${s ? "active" : ""}`,
          onClick: v,
          disabled: n.length === 0,
          children: [
            s ? /* @__PURE__ */ l(Zt, {}) : /* @__PURE__ */ l(Kt, {}),
            /* @__PURE__ */ l("span", { class: "onui-btn-label", children: s ? "Copied!" : "Copy" })
          ]
        }
      ),
      /* @__PURE__ */ l(
        "button",
        {
          class: "onui-btn",
          onClick: y,
          disabled: n.length === 0,
          children: [
            /* @__PURE__ */ l(Jt, {}),
            /* @__PURE__ */ l("span", { class: "onui-btn-label", children: "Clear" })
          ]
        }
      ),
      /* @__PURE__ */ l("div", { class: "onui-divider" }),
      /* @__PURE__ */ l(
        "button",
        {
          class: `onui-btn ${c ? "active" : ""}`,
          onClick: () => h((g) => !g),
          children: [
            /* @__PURE__ */ l(Qt, {}),
            /* @__PURE__ */ l("span", { class: "onui-btn-label", children: "Settings" })
          ]
        }
      ),
      c && /* @__PURE__ */ l("div", { class: "onui-settings", children: /* @__PURE__ */ l("div", { class: "onui-setting-row", children: [
        /* @__PURE__ */ l("label", { class: "onui-setting-label", children: "Output Level" }),
        /* @__PURE__ */ l(
          "select",
          {
            class: "onui-select",
            value: o,
            onChange: (g) => i(
              g.target.value
            ),
            children: [
              /* @__PURE__ */ l("option", { value: "compact", children: "Compact" }),
              /* @__PURE__ */ l("option", { value: "standard", children: "Standard" }),
              /* @__PURE__ */ l("option", { value: "detailed", children: "Detailed" }),
              /* @__PURE__ */ l("option", { value: "forensic", children: "Forensic" })
            ]
          }
        )
      ] }) })
    ] }),
    /* @__PURE__ */ l(
      "button",
      {
        class: `onui-toggle ${p ? "active" : ""}`,
        onClick: b,
        title: "Toggle onUI panel",
        children: /* @__PURE__ */ l(qt, {})
      }
    )
  ] });
}
function tn(t) {
  var n;
  const e = window.getComputedStyle(t);
  return {
    layout: {
      display: e.display,
      position: e.position,
      width: e.width,
      height: e.height,
      "flex-direction": e.flexDirection,
      "align-items": e.alignItems,
      "justify-content": e.justifyContent
    },
    typography: {
      "font-family": ((n = e.fontFamily.split(",")[0]) == null ? void 0 : n.trim()) || e.fontFamily,
      "font-size": e.fontSize,
      "font-weight": e.fontWeight,
      "line-height": e.lineHeight,
      "text-align": e.textAlign
    },
    colors: {
      color: e.color,
      "background-color": e.backgroundColor,
      "border-color": e.borderColor
    },
    spacing: {
      padding: e.padding,
      margin: e.margin,
      "border-radius": e.borderRadius
    }
  };
}
function nn(t) {
  const e = [], n = window.getComputedStyle(t);
  n.display !== "block" && n.display !== "inline" && e.push(`display: ${n.display}`), n.position !== "static" && e.push(`position: ${n.position}`), e.push(`${n.width} × ${n.height}`);
  const o = n.fontSize, i = n.fontWeight;
  i !== "400" ? e.push(`font: ${i} ${o}`) : e.push(`font-size: ${o}`);
  const r = n.backgroundColor;
  return r !== "rgba(0, 0, 0, 0)" && r !== "transparent" && e.push(`bg: ${r}`), e.join("; ");
}
function Oe(t) {
  let e;
  try {
    e = Object.keys(t);
  } catch {
    return null;
  }
  const n = e.find(
    (o) => o.startsWith("__reactFiber$") || o.startsWith("__reactInternalInstance$")
  );
  return n ? t[n] : null;
}
function De(t) {
  const e = t;
  return e.__v ? e.__v : e._prevVNode ? e._prevVNode : null;
}
function st(t) {
  var o, i, r, a;
  if (!t || typeof t != "object") return null;
  const n = t.type;
  if (!n) return null;
  if (typeof n == "function")
    return n.displayName || n.name || null;
  if (typeof n == "object" && n !== null) {
    const u = n;
    if (((i = (o = u.$$typeof) == null ? void 0 : o.toString) == null ? void 0 : i.call(o)) === "Symbol(react.memo)") {
      const d = u.type;
      if (typeof d == "function")
        return d.displayName || d.name || null;
    }
    if (((a = (r = u.$$typeof) == null ? void 0 : r.toString) == null ? void 0 : a.call(r)) === "Symbol(react.forward_ref)") {
      const d = u.render;
      if (typeof d == "function")
        return d.displayName || d.name || null;
    }
  }
  return null;
}
function at(t) {
  if (!t || typeof t != "object") return null;
  const n = t.type;
  return typeof n == "function" && (n.displayName || n.name) || null;
}
function on(t, e = 10) {
  const n = [];
  let o = t, i = 0;
  for (; o && i < e; ) {
    const r = o, a = st(o);
    a && !a.startsWith("_") && a !== "Fragment" && n.unshift(a), o = r.return, i++;
  }
  return n;
}
function rn(t, e = 10) {
  const n = [];
  let o = t, i = 0;
  for (; o && i < e; ) {
    const r = o, a = at(o);
    a && !a.startsWith("_") && a !== "Fragment" && n.unshift(a), o = r.__, i++;
  }
  return n;
}
function lt(t) {
  const e = Oe(t);
  if (e) {
    const u = on(e);
    if (u.length > 0)
      return u.join(" > ");
  }
  const n = De(t);
  if (n) {
    const u = rn(n);
    if (u.length > 0)
      return u.join(" > ");
  }
  let o = t;
  const i = [];
  let r = 0;
  const a = 50;
  for (; o && o !== document.body && r < a; ) {
    r++;
    try {
      const u = Oe(o);
      if (u) {
        const c = st(u);
        c && !c.startsWith("_") && c !== "Fragment" && (i.includes(c) || i.unshift(c));
      }
      const d = De(o);
      if (d) {
        const c = at(d);
        c && !c.startsWith("_") && c !== "Fragment" && (i.includes(c) || i.unshift(c));
      }
    } catch {
      break;
    }
    o = o.parentElement;
  }
  return i.length > 0 ? i.join(" > ") : null;
}
function ct(t) {
  if (t.id)
    return `#${CSS.escape(t.id)}`;
  const e = [];
  let n = t;
  for (; n && n !== document.body && n !== document.documentElement; ) {
    let o = n.tagName.toLowerCase();
    const i = n.getAttribute("data-testid"), r = n.getAttribute("data-test"), a = n.getAttribute("name");
    if (i)
      o += `[data-testid="${CSS.escape(i)}"]`;
    else if (r)
      o += `[data-test="${CSS.escape(r)}"]`;
    else if (a)
      o += `[name="${CSS.escape(a)}"]`;
    else if (n.className && typeof n.className == "string") {
      const c = n.className.split(" ").filter(Boolean).filter((h) => !h.startsWith("onui-")).slice(0, 2);
      c.length > 0 && (o += c.map((h) => `.${CSS.escape(h)}`).join(""));
    } else {
      const c = n.getAttribute("role");
      c && (o += `[role="${CSS.escape(c)}"]`);
    }
    const u = n.parentElement;
    if (u && Array.from(u.children).filter(
      (h) => h.matches(o)
    ).length > 1) {
      const s = Array.from(u.children).filter(
        (f) => f.tagName === n.tagName
      ).indexOf(n) + 1;
      s > 0 && (o += `:nth-of-type(${s})`);
    }
    e.unshift(o);
    const d = e.join(" > ");
    try {
      if (document.querySelectorAll(d).length === 1)
        return d;
    } catch {
    }
    n = n.parentElement;
  }
  return e.join(" > ");
}
function ut(t) {
  const e = [];
  let n = t, o = 0;
  const i = 4;
  for (; n && n !== document.body && o < i; ) {
    let r = n.tagName.toLowerCase();
    if (n.id)
      r += `#${n.id}`;
    else if (n.className && typeof n.className == "string") {
      const a = n.className.split(" ").filter(Boolean)[0];
      a && (r += `.${a}`);
    }
    e.unshift(r), n = n.parentElement, o++;
  }
  return n && n !== document.body && e.unshift("..."), e.join(" > ");
}
const sn = () => /* @__PURE__ */ l("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", children: [
  /* @__PURE__ */ l("line", { x1: "18", y1: "6", x2: "6", y2: "18" }),
  /* @__PURE__ */ l("line", { x1: "6", y1: "6", x2: "18", y2: "18" })
] }), an = () => /* @__PURE__ */ l("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "1.5", children: [
  /* @__PURE__ */ l("circle", { cx: "12", cy: "12", r: "2" }),
  /* @__PURE__ */ l("ellipse", { cx: "12", cy: "12", rx: "10", ry: "4" }),
  /* @__PURE__ */ l("ellipse", { cx: "12", cy: "12", rx: "10", ry: "4", transform: "rotate(60 12 12)" }),
  /* @__PURE__ */ l("ellipse", { cx: "12", cy: "12", rx: "10", ry: "4", transform: "rotate(120 12 12)" })
] }), ln = () => /* @__PURE__ */ l("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", children: /* @__PURE__ */ l("path", { d: "M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" }) }), cn = () => /* @__PURE__ */ l("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", children: [
  /* @__PURE__ */ l("path", { d: "M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" }),
  /* @__PURE__ */ l("path", { d: "M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" })
] }), un = () => /* @__PURE__ */ l("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", children: [
  /* @__PURE__ */ l("circle", { cx: "12", cy: "12", r: "10" }),
  /* @__PURE__ */ l("path", { d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" }),
  /* @__PURE__ */ l("line", { x1: "12", y1: "17", x2: "12.01", y2: "17" })
] }), dn = () => /* @__PURE__ */ l("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", children: [
  /* @__PURE__ */ l("path", { d: "M22 11.08V12a10 10 0 1 1-5.93-9.14" }),
  /* @__PURE__ */ l("polyline", { points: "22 4 12 14.01 9 11.01" })
] }), pn = () => /* @__PURE__ */ l("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", children: [
  /* @__PURE__ */ l("circle", { cx: "12", cy: "12", r: "10" }),
  /* @__PURE__ */ l("line", { x1: "12", y1: "8", x2: "12", y2: "12" }),
  /* @__PURE__ */ l("line", { x1: "12", y1: "16", x2: "12.01", y2: "16" })
] }), fn = () => /* @__PURE__ */ l("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", children: [
  /* @__PURE__ */ l("path", { d: "M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" }),
  /* @__PURE__ */ l("line", { x1: "12", y1: "9", x2: "12", y2: "13" }),
  /* @__PURE__ */ l("line", { x1: "12", y1: "17", x2: "12.01", y2: "17" })
] }), hn = () => /* @__PURE__ */ l("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", children: [
  /* @__PURE__ */ l("circle", { cx: "12", cy: "12", r: "10" }),
  /* @__PURE__ */ l("line", { x1: "12", y1: "16", x2: "12", y2: "12" }),
  /* @__PURE__ */ l("line", { x1: "12", y1: "8", x2: "12.01", y2: "8" })
] });
function Pe({
  element: t,
  onSave: e,
  onCancel: n,
  initialComment: o = "",
  initialIntent: i,
  initialSeverity: r,
  isEditing: a = !1,
  onDelete: u
}) {
  const d = it(), [c, h] = T(o), [s, f] = T(i), [p, b] = T(r), [v, y] = T(null), [g, _] = T(null), [w, m] = T(!1), x = N(null), E = N(null), z = N(c), D = N(s), M = N(p);
  R(() => {
    z.current = c;
  }, [c]), R(() => {
    D.current = s;
  }, [s]), R(() => {
    M.current = p;
  }, [p]), R(() => {
    y(tn(t)), _(lt(t)), setTimeout(() => {
      var k;
      (k = x.current) == null || k.focus();
    }, 100);
  }, [t]), R(() => {
    if (!E.current) return;
    const k = t.getBoundingClientRect(), H = E.current, Q = H.getBoundingClientRect();
    let X = k.left + k.width + 16, q = k.top;
    X + Q.width > window.innerWidth - 20 && (X = k.left - Q.width - 16), X < 20 && (X = 20), q + Q.height > window.innerHeight - 20 && (q = window.innerHeight - Q.height - 20), q < 20 && (q = 20), H.style.left = `${X}px`, H.style.top = `${q}px`;
  }, [t, d]), R(() => {
    const k = (H) => {
      H.key === "Escape" ? n() : H.key === "Enter" && (H.metaKey || H.ctrlKey) && e({
        comment: z.current,
        intent: D.current,
        severity: M.current
      });
    };
    return document.addEventListener("keydown", k), () => document.removeEventListener("keydown", k);
  }, [n, e]);
  const B = S(() => {
    e({ comment: c, intent: s, severity: p });
  }, [c, s, p, e]), O = ut(t), F = ct(t), pt = [
    { value: "fix", label: "Fix", icon: ln },
    { value: "change", label: "Change", icon: cn },
    { value: "question", label: "Question", icon: un },
    { value: "approve", label: "Approve", icon: dn }
  ], ft = [
    { value: "blocking", label: "Blocking", icon: pn },
    { value: "important", label: "Important", icon: fn },
    { value: "suggestion", label: "Suggestion", icon: hn }
  ];
  return /* @__PURE__ */ l(U, { children: [
    /* @__PURE__ */ l("div", { class: "onui-dialog-backdrop", onClick: n }),
    /* @__PURE__ */ l("div", { class: "onui-dialog", ref: E, children: [
      /* @__PURE__ */ l("div", { class: "onui-dialog-header", children: [
        /* @__PURE__ */ l("div", { children: [
          /* @__PURE__ */ l("div", { class: "onui-dialog-title", children: a ? "Edit Annotation" : "Add Annotation" }),
          /* @__PURE__ */ l("div", { class: "onui-dialog-subtitle", title: F, children: O })
        ] }),
        /* @__PURE__ */ l("button", { class: "onui-dialog-close", onClick: n, children: /* @__PURE__ */ l(sn, {}) })
      ] }),
      g && /* @__PURE__ */ l("div", { class: "onui-component-path", children: [
        /* @__PURE__ */ l(an, {}),
        /* @__PURE__ */ l("span", { children: g })
      ] }),
      /* @__PURE__ */ l(
        "textarea",
        {
          ref: x,
          class: "onui-textarea",
          placeholder: "Describe the issue or feedback...",
          value: c,
          onInput: (k) => h(k.target.value)
        }
      ),
      /* @__PURE__ */ l("div", { class: "onui-selector", children: [
        /* @__PURE__ */ l("span", { class: "onui-selector-label", children: "Intent" }),
        pt.map((k) => /* @__PURE__ */ l(
          "button",
          {
            type: "button",
            class: `onui-chip onui-chip--intent ${s === k.value ? "is-selected" : ""}`,
            "aria-pressed": s === k.value,
            "aria-label": `Intent: ${k.label}${s === k.value ? " (selected)" : ""}`,
            onClick: () => f(s === k.value ? void 0 : k.value),
            children: [
              /* @__PURE__ */ l(k.icon, {}),
              k.label
            ]
          },
          k.value
        ))
      ] }),
      /* @__PURE__ */ l("div", { class: "onui-selector", children: [
        /* @__PURE__ */ l("span", { class: "onui-selector-label", children: "Severity" }),
        ft.map((k) => /* @__PURE__ */ l(
          "button",
          {
            type: "button",
            class: `onui-chip onui-chip--severity ${p === k.value ? "is-selected" : ""}`,
            "aria-pressed": p === k.value,
            "aria-label": `Severity: ${k.label}${p === k.value ? " (selected)" : ""}`,
            onClick: () => b(p === k.value ? void 0 : k.value),
            children: [
              /* @__PURE__ */ l(k.icon, {}),
              k.label
            ]
          },
          k.value
        ))
      ] }),
      /* @__PURE__ */ l(
        "button",
        {
          class: "onui-btn",
          onClick: () => m(!w),
          style: { marginTop: "12px" },
          children: w ? "Hide Styles" : "Show Computed Styles"
        }
      ),
      w && v && /* @__PURE__ */ l("div", { class: "onui-styles", children: [
        /* @__PURE__ */ l("div", { class: "onui-styles-title", children: "Layout" }),
        Object.entries(v.layout).map(([k, H]) => /* @__PURE__ */ l("div", { class: "onui-style-row", children: [
          /* @__PURE__ */ l("span", { class: "onui-style-key", children: k }),
          /* @__PURE__ */ l("span", { class: "onui-style-value", children: H })
        ] }, k)),
        /* @__PURE__ */ l("div", { class: "onui-styles-title", style: { marginTop: "12px" }, children: "Typography" }),
        Object.entries(v.typography).map(([k, H]) => /* @__PURE__ */ l("div", { class: "onui-style-row", children: [
          /* @__PURE__ */ l("span", { class: "onui-style-key", children: k }),
          /* @__PURE__ */ l("span", { class: "onui-style-value", children: H })
        ] }, k)),
        /* @__PURE__ */ l("div", { class: "onui-styles-title", style: { marginTop: "12px" }, children: "Colors" }),
        Object.entries(v.colors).map(([k, H]) => /* @__PURE__ */ l("div", { class: "onui-style-row", children: [
          /* @__PURE__ */ l("span", { class: "onui-style-key", children: k }),
          /* @__PURE__ */ l("span", { class: "onui-style-value", children: H })
        ] }, k))
      ] }),
      /* @__PURE__ */ l("div", { class: "onui-dialog-footer", children: [
        a && u && /* @__PURE__ */ l(
          "button",
          {
            class: "onui-btn-secondary",
            onClick: u,
            style: { marginRight: "auto", color: "var(--onui-error)" },
            children: "Delete"
          }
        ),
        /* @__PURE__ */ l("button", { class: "onui-btn-secondary", onClick: n, children: "Cancel" }),
        /* @__PURE__ */ l(
          "button",
          {
            class: "onui-btn-primary",
            onClick: B,
            disabled: !c.trim(),
            children: a ? "Update" : "Add Annotation"
          }
        )
      ] })
    ] })
  ] });
}
function gn(t) {
  if (t.closest("#onui-shadow-host") || ["HTML", "HEAD", "SCRIPT", "STYLE", "META", "LINK", "NOSCRIPT"].includes(t.tagName))
    return !0;
  const n = window.getComputedStyle(t);
  if (n.display === "none" || n.visibility === "hidden" || n.opacity === "0")
    return !0;
  const o = t.getBoundingClientRect();
  return o.width === 0 || o.height === 0;
}
function _n(t) {
  return t instanceof HTMLButtonElement || t instanceof HTMLAnchorElement || t instanceof HTMLInputElement || t instanceof HTMLSelectElement || t instanceof HTMLTextAreaElement || t.hasAttribute("role") || t.hasAttribute("contenteditable") ? !0 : window.getComputedStyle(t).cursor === "pointer";
}
function bn(t) {
  return ["DIV", "SECTION", "MAIN", "ARTICLE", "ASIDE", "NAV"].includes(t.tagName);
}
function Fe(t, e) {
  const n = document.elementsFromPoint(t, e), o = [];
  for (const r of n) {
    if (r.id === "onui-shadow-host" || r.closest("#onui-shadow-host") || gn(r))
      continue;
    const a = r.getBoundingClientRect();
    o.push({ element: r, area: a.width * a.height });
  }
  if (o.length === 0)
    return null;
  const i = Math.min(...o.map((r) => r.area));
  for (const r of o) {
    const { element: a, area: u } = r, d = a.getBoundingClientRect();
    if (!(bn(a) && a.children.length > 0 && !_n(a) && d.width >= window.innerWidth * 0.8 && u > i * 8))
      return a;
  }
  return null;
}
function mn(t, e) {
  let n = 0, o = null;
  return { throttled: (...a) => {
    const u = Date.now(), d = u - n;
    d >= e ? (n = u, t(...a)) : o || (o = setTimeout(() => {
      n = Date.now(), o = null, t(...a);
    }, e - d));
  }, cancel: () => {
    o !== null && (clearTimeout(o), o = null);
  } };
}
const pe = "onui-shadow-host";
function Ue(t) {
  const e = t.target;
  return e instanceof Element && (e.id === pe || e.closest(`#${pe}`)) ? !0 : t.composedPath().some((n) => n instanceof Element && n.id === pe);
}
function vn(t) {
  const { enabled: e, throttleMs: n = 16, onElementClick: o } = t, [i, r] = T(null), a = N(null), u = N(e), d = N(o);
  R(() => {
    u.current = e;
  }, [e]), R(() => {
    d.current = o;
  }, [o]);
  const c = N(null);
  if (!c.current) {
    const { throttled: f, cancel: p } = mn((b) => {
      if (Ue(b)) {
        a.current && (r(null), a.current = null);
        return;
      }
      if (!u.current) {
        a.current && (r(null), a.current = null);
        return;
      }
      const v = Fe(b.clientX, b.clientY);
      v !== a.current && (a.current = v, r(v));
    }, n);
    c.current = { throttled: f, cancel: p };
  }
  const h = c.current.throttled, s = S(
    (f) => {
      if (!u.current || !d.current || Ue(f)) return;
      const p = Fe(f.clientX, f.clientY);
      p && (f.preventDefault(), f.stopPropagation(), d.current(p));
    },
    []
    // Stable - uses refs internally
  );
  return R(() => {
    if (!e) {
      r(null), a.current = null;
      return;
    }
    return document.addEventListener("mousemove", h, { passive: !0 }), document.addEventListener("click", s, { capture: !0 }), () => {
      var f;
      document.removeEventListener("mousemove", h), document.removeEventListener("click", s, { capture: !0 }), (f = c.current) == null || f.cancel();
    };
  }, [e, h, s]), {
    hoveredElement: i
  };
}
const G = "[onUI][messaging]", je = 15e3;
function Be(t) {
  try {
    const e = new URL(t);
    return `${e.origin}${e.pathname}`;
  } catch {
    return "invalid-url";
  }
}
let We = 0;
function xn() {
  return We += 1, `msg-${Date.now()}-${We}`;
}
function yn() {
  try {
    return typeof chrome < "u" && typeof chrome.runtime < "u" && typeof chrome.runtime.id < "u";
  } catch {
    return !1;
  }
}
class be extends Error {
  constructor() {
    super("Extension has been updated. Please refresh the page."), this.name = "ExtensionContextInvalidatedError";
  }
}
class wn extends Error {
  constructor(e, n) {
    super(`Message ${e} timed out after ${n}ms`), this.name = "ExtensionMessageTimeoutError";
  }
}
function L(t) {
  return t instanceof be ? !0 : t instanceof Error ? t.message.includes("Extension context invalidated") || t.message.includes("message channel closed") || t.message.includes("Receiving end does not exist") || t.message.includes("No response from background script") : !1;
}
async function j(t) {
  const e = xn(), n = Date.now();
  if (!yn())
    throw console.error(`${G} ${e} blocked: invalid extension context before send`, {
      type: t.type,
      url: Be(window.location.href)
    }), new be();
  const i = {
    ...t,
    meta: {
      ...t.meta ?? {},
      requestId: e,
      sentAt: n,
      source: "content"
    }
  };
  console.log(`${G} ${e} send`, {
    type: t.type,
    url: Be(window.location.href)
  });
  let r;
  const a = new Promise((u, d) => {
    r = window.setTimeout(() => {
      d(new wn(t.type, je));
    }, je);
  });
  try {
    const u = await Promise.race([
      chrome.runtime.sendMessage(i),
      a
    ]), d = Date.now() - n;
    if (u === void 0)
      throw console.error(`${G} ${e} no response`, {
        type: t.type,
        durationMs: d
      }), new Error("No response from background script");
    const c = u;
    return console.log(`${G} ${e} response`, {
      type: t.type,
      durationMs: d,
      success: c.success,
      error: c.error,
      hasData: "data" in c
    }), u;
  } catch (u) {
    const d = Date.now() - n, c = L(u);
    throw console.error(`${G} ${e} failed`, {
      type: t.type,
      durationMs: d,
      invalidContext: c,
      error: u instanceof Error ? u.message : u
    }), c ? new be() : u;
  } finally {
    r !== void 0 && window.clearTimeout(r);
  }
}
async function kn() {
  return j({
    type: "GET_ANNOTATIONS",
    payload: { url: window.location.href }
  });
}
async function $n(t) {
  return j({
    type: "CREATE_ANNOTATION",
    payload: t
  });
}
async function Cn(t, e) {
  return j({
    type: "UPDATE_ANNOTATION",
    payload: { id: t, update: e }
  });
}
async function En(t) {
  return j({
    type: "DELETE_ANNOTATION",
    payload: { id: t }
  });
}
async function Sn() {
  return j({
    type: "CLEAR_ANNOTATIONS",
    payload: { url: window.location.href }
  });
}
async function An() {
  return j({
    type: "GET_TAB_RUNTIME_STATE"
  });
}
async function Tn(t) {
  return j({
    type: "SET_TAB_ENABLED",
    payload: { enabled: t }
  });
}
async function In(t) {
  return j({
    type: "SET_ANNOTATE_MODE",
    payload: { annotateMode: t }
  });
}
function Mn(t) {
  if (!t || typeof t != "object") return !1;
  const e = t;
  if (e.type !== "TAB_RUNTIME_STATE_CHANGED" || !e.payload || typeof e.payload != "object") return !1;
  const n = e.payload;
  if (typeof n.tabId != "number" || !n.state || typeof n.state != "object") return !1;
  const o = n.state;
  return typeof o.enabled == "boolean" && typeof o.annotateMode == "boolean";
}
const C = "[onUI][useAnnotations]";
function Nn() {
  const [t, e] = T([]), [n, o] = T(!0), [i, r] = T(null), [a, u] = T(!1), d = N(a);
  d.current = a;
  const c = N(t);
  c.current = t;
  const h = N(0), s = S((g) => (h.current += 1, `${g}-${Date.now()}-${h.current}`), []);
  R(() => {
    console.log(`${C} state`, {
      annotationsCount: t.length,
      isLoading: n,
      error: i,
      isContextInvalid: a
    });
  }, [t.length, n, i, a]);
  const f = S(async () => {
    var w;
    const g = s("refresh");
    if (d.current) {
      console.warn(`${C} ${g} skipped: context already invalid`);
      return;
    }
    const _ = Date.now();
    console.log(`${C} ${g} start`, {
      url: window.location.href
    });
    try {
      o(!0), r(null);
      const m = await kn();
      console.log(`${C} ${g} response`, {
        success: m.success,
        count: (w = m.data) == null ? void 0 : w.length,
        error: m.error
      }), m.success && m.data ? e(m.data) : r(m.error || "Failed to load annotations");
    } catch (m) {
      L(m) && u(!0);
      const x = m instanceof Error ? m.message : "Unknown error";
      console.error(`${C} ${g} failed`, {
        error: x,
        contextInvalidated: L(m)
      }), r(x);
    } finally {
      const m = Date.now() - _;
      console.log(`${C} ${g} end`, { durationMs: m }), o(!1);
    }
  }, [s]);
  R(() => {
    f();
  }, [f]);
  const p = S(
    async (g) => {
      var m;
      const _ = s("add");
      if (d.current)
        return console.warn(`${C} ${_} skipped: context already invalid`), null;
      const w = Date.now();
      console.log(`${C} ${_} start`, {
        selector: g.selector,
        pageUrl: g.pageUrl
      });
      try {
        r(null);
        const x = await $n(g);
        if (console.log(`${C} ${_} response`, {
          success: x.success,
          annotationId: (m = x.data) == null ? void 0 : m.id,
          error: x.error
        }), x.success && x.data) {
          const E = x.data;
          return e((z) => [...z, E]), E;
        }
        return r(x.error || "Failed to add annotation"), null;
      } catch (x) {
        L(x) && u(!0);
        const E = x instanceof Error ? x.message : "Unknown error";
        return console.error(`${C} ${_} failed`, {
          error: E,
          contextInvalidated: L(x)
        }), r(E), null;
      } finally {
        const x = Date.now() - w;
        console.log(`${C} ${_} end`, { durationMs: x });
      }
    },
    [s]
  ), b = S(
    async (g, _) => {
      const w = s("update");
      if (d.current)
        return console.warn(`${C} ${w} skipped: context already invalid`, { id: g }), !1;
      const m = Date.now();
      console.log(`${C} ${w} start`, { id: g, update: _ });
      try {
        r(null);
        const x = await Cn(g, _);
        if (console.log(`${C} ${w} response`, {
          success: x.success,
          error: x.error
        }), x.success && x.data) {
          const E = x.data;
          return e(
            (z) => z.map((D) => D.id === g ? E : D)
          ), !0;
        }
        return r(x.error || "Failed to update annotation"), !1;
      } catch (x) {
        L(x) && u(!0);
        const E = x instanceof Error ? x.message : "Unknown error";
        return console.error(`${C} ${w} failed`, {
          error: E,
          contextInvalidated: L(x)
        }), r(E), !1;
      } finally {
        const x = Date.now() - m;
        console.log(`${C} ${w} end`, { durationMs: x });
      }
    },
    [s]
  ), v = S(
    async (g) => {
      const _ = s("delete");
      if (d.current)
        return console.warn(`${C} ${_} skipped: context already invalid`, { id: g }), !1;
      const w = Date.now();
      console.log(`${C} ${_} start`, { id: g });
      try {
        r(null);
        const m = await En(g);
        return console.log(`${C} ${_} response`, {
          success: m.success,
          error: m.error
        }), m.success ? (e((x) => x.filter((E) => E.id !== g)), !0) : (r(m.error || "Failed to delete annotation"), !1);
      } catch (m) {
        L(m) && u(!0);
        const x = m instanceof Error ? m.message : "Unknown error";
        return console.error(`${C} ${_} failed`, {
          error: x,
          contextInvalidated: L(m)
        }), r(x), !1;
      } finally {
        const m = Date.now() - w;
        console.log(`${C} ${_} end`, { durationMs: m });
      }
    },
    [s]
  ), y = S(async () => {
    const g = s("clear");
    if (d.current)
      return console.warn(`${C} ${g} skipped: context already invalid`), !1;
    const _ = Date.now(), w = c.current.length;
    console.log(`${C} ${g} start`, {
      url: window.location.href,
      annotationCount: w
    });
    try {
      r(null);
      const m = await Sn();
      return console.log(`${C} ${g} response`, {
        success: m.success,
        error: m.error
      }), m.success ? (e([]), !0) : (r(m.error || "Failed to clear annotations"), !1);
    } catch (m) {
      L(m) && u(!0);
      const x = m instanceof Error ? m.message : "Unknown error";
      return console.error(`${C} ${g} failed`, {
        error: x,
        contextInvalidated: L(m)
      }), r(x), !1;
    } finally {
      const m = Date.now() - _;
      console.log(`${C} ${g} end`, { durationMs: m });
    }
  }, [s]);
  return {
    annotations: t,
    isLoading: n,
    error: i,
    isContextInvalid: a,
    addAnnotation: p,
    updateAnnotation: b,
    deleteAnnotation: v,
    clearAnnotations: y,
    refreshAnnotations: f
  };
}
const Ve = "[onUI][useTabRuntimeState]";
function Rn() {
  const [t, e] = T(!1), [n, o] = T(!1), [i, r] = T(!1), a = N(t), u = N(n), d = N(i);
  a.current = t, u.current = n, d.current = i, R(() => {
    (async () => {
      try {
        const b = await An();
        b.success && b.data ? (e(b.data.enabled), o(b.data.annotateMode)) : b.error && console.error(`${Ve} initial sync unsuccessful`, b.error);
      } catch (b) {
        L(b) && r(!0), console.error(`${Ve} initial sync failed`, b);
      }
    })();
  }, []), R(() => {
    const p = (b) => {
      if (!Mn(b))
        return;
      const v = b.payload.state;
      e(v.enabled), o(v.annotateMode);
    };
    return chrome.runtime.onMessage.addListener(p), () => chrome.runtime.onMessage.removeListener(p);
  }, []);
  const c = S(async (p) => {
    if (d.current) return;
    const b = a.current, v = u.current;
    e(p), p || o(!1);
    try {
      const y = await Tn(p);
      y.success && y.data ? (e(y.data.enabled), o(y.data.annotateMode)) : (e(b), o(v));
    } catch (y) {
      L(y) && r(!0), e(b), o(v);
    }
  }, []), h = S(async (p) => {
    if (d.current || !a.current)
      return;
    const b = u.current;
    o(p);
    try {
      const v = await In(p);
      v.success && v.data ? (e(v.data.enabled), o(v.data.annotateMode)) : o(b);
    } catch (v) {
      L(v) && r(!0), o(b);
    }
  }, []), s = S(async () => {
    await c(!a.current);
  }, [c]), f = S(async () => {
    await h(!u.current);
  }, [h]);
  return {
    enabled: t,
    annotateMode: n,
    isContextInvalid: i,
    setEnabled: c,
    setAnnotateMode: h,
    toggleEnabled: s,
    toggleAnnotateMode: f
  };
}
function zn(t) {
  const e = t.getBoundingClientRect(), n = dt(t);
  return {
    top: n ? e.top : e.top + window.scrollY,
    left: n ? e.left : e.left + window.scrollX,
    width: e.width,
    height: e.height,
    isFixed: n
  };
}
function dt(t) {
  let e = t;
  for (; e && e !== document.body; ) {
    const n = window.getComputedStyle(e);
    if (n.position === "fixed" || n.position === "sticky")
      return !0;
    e = e.parentElement;
  }
  return !1;
}
function Hn(t) {
  var _;
  const { element: e, comment: n, selectedText: o, selectionRect: i, intent: r, severity: a } = t, u = ct(e), d = ut(e);
  let c;
  if (i) {
    const w = dt(e);
    c = {
      top: w ? i.top : i.top + window.scrollY,
      left: w ? i.left : i.left + window.scrollX,
      width: i.width,
      height: i.height,
      bottom: w ? i.bottom : i.bottom + window.scrollY,
      right: w ? i.right : i.right + window.scrollX,
      isFixed: w
    };
  } else
    c = zn(e);
  const h = {};
  for (const w of Array.from(e.attributes))
    !w.name.startsWith("on") && !w.name.startsWith("data-") && (h[w.name] = w.value);
  const s = e.getAttribute("role") || Ln(e) || void 0, f = ((_ = e.textContent) == null ? void 0 : _.trim().slice(0, 200)) || void 0, p = lt(e) || void 0, b = nn(e), v = e.getBoundingClientRect(), y = v.left / window.innerWidth * 100, g = v.top + window.scrollY;
  return {
    selector: u,
    elementPath: d,
    tagName: e.tagName.toLowerCase(),
    comment: n,
    ...o !== void 0 && { selectedText: o },
    boundingBox: c,
    pageUrl: window.location.href,
    pageTitle: document.title,
    attributes: h,
    ...s !== void 0 && { role: s },
    ...f !== void 0 && { textContent: f },
    // OnUI fields
    ...p !== void 0 && { reactComponents: p },
    computedStyles: b,
    viewportX: y,
    documentY: g,
    ...r !== void 0 && { intent: r },
    ...a !== void 0 && { severity: a },
    status: "pending"
  };
}
function Ln(t) {
  const e = t.tagName.toLowerCase();
  return {
    a: "link",
    button: "button",
    img: "img",
    input: On(t),
    select: "combobox",
    textarea: "textbox",
    nav: "navigation",
    main: "main",
    header: "banner",
    footer: "contentinfo",
    aside: "complementary",
    article: "article",
    section: "region",
    form: "form",
    table: "table",
    ul: "list",
    ol: "list",
    li: "listitem"
  }[e];
}
function On(t) {
  const e = t.type || "text";
  return {
    button: "button",
    checkbox: "checkbox",
    radio: "radio",
    range: "slider",
    search: "searchbox",
    submit: "button",
    reset: "button",
    text: "textbox",
    email: "textbox",
    password: "textbox",
    tel: "textbox",
    url: "textbox"
  }[e] ?? "textbox";
}
function Dn() {
  const {
    enabled: t,
    annotateMode: e,
    toggleAnnotateMode: n,
    isContextInvalid: o
  } = Rn();
  return /* @__PURE__ */ l(U, { children: [
    o && /* @__PURE__ */ l("div", { class: "onui-refresh-banner", children: [
      /* @__PURE__ */ l("span", { children: "onUI extension has been updated." }),
      /* @__PURE__ */ l("button", { onClick: () => window.location.reload(), children: "Refresh page" })
    ] }),
    t && /* @__PURE__ */ l(
      Pn,
      {
        annotateMode: e,
        onToggleAnnotateMode: n
      }
    )
  ] });
}
function Pn({ annotateMode: t, onToggleAnnotateMode: e }) {
  const {
    annotations: n,
    addAnnotation: o,
    updateAnnotation: i,
    deleteAnnotation: r,
    clearAnnotations: a,
    isContextInvalid: u
  } = Nn(), [d, c] = T("standard"), [h, s] = T(null), [f, p] = T(null), b = S((M) => {
    s(M), p(null);
  }, []), { hoveredElement: v } = vn({
    enabled: t && !h && !f,
    onElementClick: b
  }), y = S(
    async (M) => {
      if (!h) return;
      const B = Hn({
        element: h,
        comment: M.comment,
        intent: M.intent,
        severity: M.severity
      });
      await o(B), s(null);
    },
    [h, o]
  ), g = S(
    async (M) => {
      f && (await i(f.id, M), p(null));
    },
    [f, i]
  ), _ = S(async () => {
    f && (await r(f.id), p(null));
  }, [f, r]), w = S(() => {
    s(null), p(null);
  }, []), m = S((M) => {
    p(M), s(null);
  }, []), x = S(() => {
    if (!f) return null;
    try {
      return document.querySelector(f.selector);
    } catch {
      return null;
    }
  }, [f]), E = S(async () => {
    await a();
  }, [a]), z = f ? x() : null;
  return /* @__PURE__ */ l(U, { children: [
    u && /* @__PURE__ */ l("div", { class: "onui-refresh-banner", children: [
      /* @__PURE__ */ l("span", { children: "onUI extension has been updated." }),
      /* @__PURE__ */ l("button", { onClick: () => window.location.reload(), children: "Refresh page" })
    ] }),
    !(h !== null || f !== null) && /* @__PURE__ */ l(
      en,
      {
        isAnnotateMode: t,
        onToggleAnnotateMode: () => {
          e();
        },
        annotations: n,
        outputLevel: d,
        onOutputLevelChange: c,
        onClearAnnotations: E
      }
    ),
    t && v && !h && !f && /* @__PURE__ */ l(de, { element: v }),
    h && /* @__PURE__ */ l(de, { element: h, selected: !0 }),
    z && /* @__PURE__ */ l(de, { element: z, selected: !0 }),
    h && /* @__PURE__ */ l(
      Pe,
      {
        element: h,
        onSave: y,
        onCancel: w
      }
    ),
    f && z && /* @__PURE__ */ l(
      Pe,
      {
        element: z,
        initialComment: f.comment,
        initialIntent: f.intent,
        initialSeverity: f.severity,
        isEditing: !0,
        onSave: g,
        onCancel: w,
        onDelete: _
      }
    ),
    /* @__PURE__ */ l(
      Ot,
      {
        annotations: n,
        onMarkerClick: m
      }
    )
  ] });
}
function Fn() {
  const t = Ct.init();
  It(t);
  const e = document.createElement("div");
  e.id = "onui-app", t.appendChild(e), wt(/* @__PURE__ */ l(Dn, {}), e);
}
console.log("[onUI] Content script loaded");
window.__ONUI_CONTENT_BOOTSTRAPPED__ || (window.__ONUI_CONTENT_BOOTSTRAPPED__ = !0, Fn());
